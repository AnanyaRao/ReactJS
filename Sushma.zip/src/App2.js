import React from 'react'  
import './App.css'  
import 'bootstrap/dist/css/bootstrap.min.css'  
import PropTypes from 'prop-types'  
class App2 extends React.Component {  
constructor() {  
super()  
this.state = {  
course: "React", count: 1, days: 5, timeUp: "true"  
}  
}  
render() {  
return (<React.Fragment> JSX looping  
<Result greet="good Morning" count="10"/>  
<Result />  
</React.Fragment>)  
}  
}  
class Result extends React.Component{  
render(){  
return(<div> Child Component  
<h1> {this.props.greet}</h1>  
<h1> {this.props.count} </h1>  
</div>)  
}  
}  
Result.defaultProps= {  
greet:"Hello",  
count:"0"  
}  
Result.propTypes ={  
count:PropTypes.number,  
greet:PropTypes.string  
}  
// para 1-> HTML tag  
//para 2 -> attribute class, style, id  
//para3 -> Content, child element  
export default App2