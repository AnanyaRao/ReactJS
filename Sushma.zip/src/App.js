import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <h1>hello world!</h1>
      <p>Ananya</p>
    </div>
  );
}

export default App;
