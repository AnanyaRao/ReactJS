import React, { Component } from 'react';
import AXIOS from 'axios';
class LifeCycle extends React.Component {
    constructor() {
        super();
        this.state = { count: 1 };
        console.log('Init', this.state.count);
    }
   
updateMe = () => this.setState({ count: this.state.count + 1 });

    static getDerivedStateFromProps(props, state) {
        if (state.count > 10) {
            return { count: 20 }
        }
        return null;
    }
    componentDidMount() {
        console.log('After Mount', this.state.count);
    }
    componentWillMount() {
        console.log('Before Mount', this.state.count);
    }
    render() {
        console.log("In render method")
        return (<React.Fragment> JSX looping
<h1> {this.state.count}</h1>
<button onClick={this.updateMe}>Update</button>
            <Result countProp={this.state.count} />
        </React.Fragment>)
    }
}
class Result extends React.Component {
    static getDerivedStateFromProps() {
        console.log("In child getDerivedStateFromProps")
        return null
    }
    shouldComponentUpdate(nextProps, nextState) {
        if (nextProps.countProp > 5) {
            return false
        }
        return true

    }
    getSnapshotBeforeUpdate(prevState, prevProps) {
        return "Some data"
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(snapshot) // Some data  
    }
    componentWillMount() {
        console.log('Before Mount', this.state.count);
    }
    render() {
        console.log("in render of child")
        return (<div> <h1> Child Component </h1>
            <h2> {this.props.countProp}</h2>
        </div>)
    }
}
// para 1-> HTML tag  
//para 2 -> attribute class, style, id  
//para3 -> Content, child element  
export default LifeCycle;