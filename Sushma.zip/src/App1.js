import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

class App1 extends React.Component{

    constructor(){
        super();
        this.state={
            course:"React",count:1
        }
        this.handleClick=this.handleClick.bind(this);
    }
    getData(){
        return "value";
    }
    handleClick=()=>{
        
        this.setState({count:this.state.count+1})
    };
    render(){
        var emp=[{
            empNO:101,empName:"Ananya"
        },{
            empNO:102,empName:"Lohith" 
        }]
       var empPush=[];

        for(let i=0;i<2;i++){
            var data= (<li>{emp[i].empNO} - {emp[i].empName} </li>)  
            empPush.push(data);
        }
        return(
            <React.Fragment>
                {empPush}
                {this.state.course}

                <h1 className="objStyle">Class Name {this.getData()}</h1>
                <h2>Welcome {new Date().toDateString()}</h2>
                <h2>{this.state.count}</h2>
                <button onClick={this.handleClick}>Start</button><br/>
                <button className="btn btn-primary">Sign In</button>
                </React.Fragment>
        )
    }
}

export default App1;