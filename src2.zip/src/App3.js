import React from 'react';
class App3 extends  React.Component
{
    state={name:"Iwa",id:1};

    render(){
        return(
        <React.Fragment>
            <h1>{this.state.name}{this.state.id}</h1>
            </React.Fragment>
    );
}
       
    
}
export default App3;