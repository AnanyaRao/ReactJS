import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    
    <React.Fragment>
   <h1>Iwa</h1>
   <h2>React JS</h2>
   </React.Fragment>
  );
}

export default App;
