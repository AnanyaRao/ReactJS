import React from 'react';
class App4 extends  React.Component
{
    state={seconds:0};

    timer=()=>
    {
      this.setState({
          seconds:this.state.seconds+1
      });
    }
    start=()=>{
    setInterval(this.timer,1000);
    }
    render(){
        return(
        <React.Fragment>
            <h1>{this.state.seconds}</h1>
            <button onClick={this.start}>Start</button>
            </React.Fragment>
    );
}
       
    
}
export default App4;