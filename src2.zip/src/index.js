import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App6 from './App6';
import {App1,App2} from './App1';
import * as serviceWorker from './serviceWorker';

//ReactDOM.render(<React.Fragment><App1/><App2/></React.Fragment>, document.getElementById('root'));
ReactDOM.render(<App6/>, document.getElementById('root'));
//ReactDOM.render(<App2/>, document.getElementById('root'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
