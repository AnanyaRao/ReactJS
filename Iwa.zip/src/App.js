import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  
  
  return (
    
    <React.Fragment>
    <h1>Ananya</h1>
    <h2>Rao</h2>
    </React.Fragment>
  );
}

export default App;
