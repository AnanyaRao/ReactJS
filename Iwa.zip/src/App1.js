import React from 'react';

class App1 extends React.Component {
    render(){
        var x=20,y=80;
        return (
            <React.Fragment>
                <h2>App1-{x+y}</h2>
                <button className="button">Submit</button>
                </React.Fragment>
        )
    }
}

class App2 extends React.Component {
    render(){
        var x=20,y=80;
        return (
            <React.Fragment>
                <h2>App2-{x}{">"}{y}{":"}{x>y?'true':'false'}</h2>
                </React.Fragment>
        )
    }
}

class App3 extends React.Component {
    render() {
            let highlight = {
                    color: 'green',backgroundColor:'grey'
             }
            return(<React.Fragment>
                   <h1 style={highlight}>Welcome to React</h1> 
            </React.Fragment>)
    }
}

class App4 extends React.Component {
    render() {
            let element = null;
            
            let isLoggedIn = document.getElementById("abc");
            
            isLoggedIn ? element = <h2>Welcome Admin</h2>: element = <h2>Please Login</h2>
            return (<React.Fragment>
                isLoggedIn=<input id="abc" name="abc" type="text"/>
                    {element}
            </React.Fragment>)  
    }
}


export {App1,App2,App3,App4};