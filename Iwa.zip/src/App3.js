import React from 'react';
class App3 extends React.Component{
    render(){
return(
    <div>

        <h1>{this.props.name}</h1>
        </div>
)

    }
}
export default App3;
