import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

class WebForm extends React.Component
{
state={name:"Ananya",zip:"567107"}
updateState=(e)=>
{
this.setState({zip:e.target.value});
}
render()
{
return(
<div>
<Child nameProp={this.state.name} zipProp={this.state.zip} updateStateprop={this.updateState} />
</div>
)
}
}
class Child extends React.Component{
render()
{
  
return(
    <html>
        <head>
            </head>
            <body className="body">
            <h1 className="h1">Welcome {this.props.nameProp}!!</h1>
            <h4 className="h4">Billing Address</h4>
        
      <form class="form-horizontal" >
      

    <div class="container" >
        <div class="row">
          <div class="col-sm-10">
            
           
                      
  <div class="form-group">
    <label for="email" > Email</label>
            <div class="col-sm-10">
            <input type="email" id="email" class="form-control" name="email" placeholder="ananya@example.com"/>
  </div>
  </div>  
  <div class="form-group">
            <label for="adr" className="lable">Address</label>
            <div class="col-sm-10">
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street"/><br/>
            </div>
          </div>
<div class="form-group">         
            <label for="city" className="lable"> City</label>
            <div class="col-sm-10">
            <input type="text" id="city" name="city" placeholder="Bangalore"/>
            </div>
          </div>
 <div class="form-group">
            <label for="state" className="lable">State</label>
            <div class="col-sm-10">
            <input type="text" id="state" name="state" placeholder="Karnataka"/>
            </div>
          </div>
 <div class="form-group">         
            <label for="zip" className="lable">Zip</label>
            <div class="col-sm-10">
            <input type="text" value={this.props.zipProp} onChange={this.props.updateStateprop} /><b>{this.props.zipProp}</b>
            
            </div>
          </div>         
            </div>
          </div>
          
          
          <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
    <input type="submit" value="Continue to checkout" class="btn btn-success"/>
    </div>
  </div>
         
      
     </div>
      </form>

  

    </body>
    </html>

)
}
}
export default WebForm;