import React from 'react';
class App5 extends React.Component
{
state={name:"Iwa"}
updateState=(e)=>
{
this.setState({name:e.target.value});
}
render()
{
return(
<div>
<Child nameProp={this.state.name} updateStateprop={this.updateState} />
</div>
)
}
}
class Child extends React.Component{
render()
{
    
return(
<div>
<input type="text" value={this.props.nameProp}
onChange={this.props.updateStateprop} />
<h1>{this.props.nameProp}</h1>
</div>
)
}
}
export default App5;