import React from 'react';
class App2 extends React.Component{
    state={name:"Ananya",id:1,seconds:0};
    timer=()=>{
        this.setState({
            seconds:this.state.seconds+1
        });
       
    };
    start=()=>{
        setInterval(this.timer,1000)

    } ;
    render(){
        return(
            <React.Fragment>
            <h1>{this.state.name}{this.state.id}{this.state.seconds}</h1>
            <button onClick={this.start}>Start</button>
            </React.Fragment>
        )}
    }
    export default App2;
