import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App2 from './App2';
import Router1 from './Router1';
import App3 from './App3';
import App4 from './App4';
import App5 from './App5';
import Hooks from './Hooks';
import Hooks1 from './Hooks1';
import Hooks2 from './Hooks2';
import CreateUser from './createUser';
import UserList from './userList';
import WebForm from './WebForm';
//import {App1,App2,App3,App4} from'./App1';

import * as serviceWorker from './serviceWorker';

ReactDOM.render(<Hooks1/>, document.getElementById('root'));

//ReactDOM.render(<Hooks2/>, document.getElementById('root'));

//ReactDOM.render(<Hooks/>, document.getElementById('root'));
//ReactDOM.render(<Router1/>, document.getElementById('root'));
//ReactDOM.render(<App5/>, document.getElementById('root'));
//ReactDOM.render(<App4 name="Ananya"/>, document.getElementById('root'));
//ReactDOM.render(<React.Fragment><App1/><App2/><App3/><App4/></React.Fragment>, document.getElementById('root'));

//If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
/*
export default class AxiosDemo extends React.Component {
    render() {
        return(
            <div>
                <h1>Axios Demo</h1>
                <h3>Add user</h3>
                <CreateUser />
                <br />
                <h3>Users</h3>
                <UserList />
                <hr />
            </div>
        );
    }
}



/*
const numbers=[1,2,3,4,5];  
const updatedNums=numbers.map((number)=>{  
return <li>{number}</li>;  
});  
ReactDOM.render(<ul>{updatedNums}</ul>, document.getElementById('root'));
*/
serviceWorker.unregister();
