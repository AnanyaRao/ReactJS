import React from 'react';  
import Home from './Home';
import Contact from './Contact';
import LifeCycle from './LifeCycle';
import {BrowserRouter as Router, Route,Link} from 'react-router-dom'; 
class Router1 extends React.Component  
{  
render(){  
return(  
<Router>  
<React.Fragment>  
<Link to="/home">Home</Link>|  
<Link to="/contact">Contact US</Link>|
<Link to="/lifecycle">Life Cycle</Link>   
<Route exact path="/" component={Home} />  
<Route path="/home" component={Home} />  
<Route path ="/contact" component={Contact} />  
<Route path ="/lifecycle" component={LifeCycle} />
</React.Fragment>  
</Router>  
)  
}  
}  

export default Router1;