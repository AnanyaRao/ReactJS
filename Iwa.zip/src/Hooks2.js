import React, { useState } from "react";  
import "./App.css";  
const Hooks2 = () =>  
{  
let [Machine,setMachine]=useState({  
Machine:"PUNE664321",  
RAM:16,  
Offline:true  
})  
 
const toggleStatus = () =>  
{  
const cpy_Machine={...Machine};  
cpy_Machine.Offline=!cpy_Machine.Offline;  
setMachine(cpy_Machine);  
console.log(cpy_Machine.Offline);  
}  
return(  
<React.Fragment>  
<h3>Name of the machine: {Machine.Machine}</h3>  
<h3>Ram:{Machine.RAM}</h3>  
<h3>Status: {Machine.Offline?'offline':'Online'}</h3>  
<button onClick={toggleStatus} >Toggle status</button>  
</React.Fragment>  
);  
};  
export default Hooks2;