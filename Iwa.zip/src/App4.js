import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
//import {render} from 'render-dom'
class App4 extends React.Component{
    state={name:"name",seconds:0}
    timer=()=>{
        this.setState({
            seconds:this.state.seconds+1
        });
       
    };
    start=()=>{
        setInterval(this.timer,1000)

    } ;
    render(){
return(
<React.Fragment>
    <Child nameProp={this.state.name} func={this.start} sec={this.state.seconds}/>
    </React.Fragment>
)
    }
}

class Child extends React.Component{
    render(){
        return(
            <React.Fragment>
            <h1>Hello {this.props.nameProp} {this.props.sec}</h1>
            <button class="btn btn-success" onClick={this.props.func}>Start</button>
            </React.Fragment>
        )
    }
}

export default App4;