import React from 'react';
class App7 extends React.Component
{
state={name:"Iwa"}

updateState=(e)=>
{
this.setState({name:e.target.value});
}

render()
{
    return(
        <div>
            <input type="text" value={this.state.name}
            onChange={this.updateState} />
            <h1>{this.state.name}</h1>
            </div>
    )
}
}

export default App7;