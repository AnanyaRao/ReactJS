import React,{Component} from 'react';
export default class Lifecycle extends React.Component{
    constructor()
    {
        super();
        this.state={number:10};
        console.log('Init',this.state.number);
    }

    updateMe=()=> this.setState({number:this.state.number+1});
 
    render()
    {  console.log('On mount:',this.state.number);
        return(
            <React.Fragment>
              <button onClick={this.updateMe}>Update</button>
            </React.Fragment>
        );
    }
    componentWillMount()
    {
        console.log('Before Mount',this.state.number);
    }
    componentDidMount()
    {
        console.log('After Mount',this.state.number);
    }

    componentWillUpdate()
    {
        console.log('Will Update',this.state.number);
    }

    componentDidUpdate()
    {
        console.log('After Update',this.state.number);
    }
    componentWillUnmount()
    {
        console.log('Unmount',this.state.number);
    }
    
}