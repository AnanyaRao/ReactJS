import React from 'react';

class Contact extends React.Component{
    render()
    {
        return(
            <h1>Contact page here</h1>
        )
    }
}

export default Contact;