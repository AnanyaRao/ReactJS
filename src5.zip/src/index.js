import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import AppHooks2 from './AppHooks2';
import {App1,App2} from './App1';
import * as serviceWorker from './serviceWorker';

//ReactDOM.render(<React.Fragment><App1/><App2/></React.Fragment>, document.getElementById('root'));
//ReactDOM.render(<Lifecycle />, document.getElementById('root'));

ReactDOM.render(<AppHooks2 />, document.getElementById('root'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA



const numbers=[1,2,3,4,5];
const updatedNums=numbers.map((number)=>{
    return <li>{number}</li>;
});
//ReactDOM.render(<ul>{updatedNums}</ul>, document.getElementById('root'));
serviceWorker.unregister();
