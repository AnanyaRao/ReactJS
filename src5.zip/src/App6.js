import React from 'react';
import { render } from 'react-dom';
class App6 extends React.Component{
    state={
        name:"Iwa",id:1,seconds:0
    }

    timer=()=>
    {
      this.setState({
          seconds:this.state.seconds+1
      });
    }
    start=()=>{
    setInterval(this.timer,1000);
    }

render(){
    return(
        <React.Fragment>
            <Child seconds={this.state.seconds} nameProp={this.state.name} idProp={this.state.id} func={this.start}/>
            </React.Fragment>
    )
}
}

class Child extends React.Component
{

    render()
    {
        return(
            <div>
            <h1>{this.props.nameProp}{this.props.idProp}</h1>
            <button onClick={this.props.func} >Start</button>
            <h2>{this.props.seconds}</h2>
       </div> )
    }
}
export default App6;