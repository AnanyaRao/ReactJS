import React from "react";
import "./App.css";

const AppHooks = () =>
{
    let Machine="PUNE664321";
    let RAM= 16;
    let Offline=true;

const toggleStatus = () =>
{
    Offline=!Offline;
    console.log(Offline);
}
return(
<React.Fragment>
    <h3>Name of the machine: {Machine}</h3>
    <h3>Ram:{RAM}</h3>
    <h3>Status: {Offline?'offline':'Online'}</h3>
    <button onClick={toggleStatus} >Toggle status</button>

    </React.Fragment>
);

};
export default AppHooks;