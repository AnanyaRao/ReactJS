import React from 'react';

class Home extends React.Component{
    render()
    {
        return(
            <h1>Home page here</h1>
        )
    }
}

export default Home;