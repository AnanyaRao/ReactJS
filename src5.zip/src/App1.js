import React from 'react';
class App1 extends React.Component{
render()
{ var x=20,y=80;
    return(<React.Fragment>
        <h1>{x+y+y}</h1>
        <button className="button">Submit</button>
        
    </React.Fragment>)
}
}

class App2 extends React.Component{
    render()
    {
        return(<React.Fragment>
            <h1>Iwa</h1>
            </React.Fragment>)
    }
}
export {App1,App2};