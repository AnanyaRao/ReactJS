import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormsModule } from '@angular/forms';
import { ViewDetailsService } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {


  flightDetails : FlightBooking[];

successMessage:string;

errorMessage:string;

  constructor(private fb: FormBuilder, private bookFlightService: ViewDetailsService) {
   
     this.fb.group({
      passengerName: ['',Validators.required],
      
      bookingId: ['',[Validators.required]],
      noOfTickets: ['',[Validators.required,Validators.min(1)]],
      totalAmount: ['',Validators.required],
    })

   }

  ngOnInit() {
    this.view();
}

  view() {
    return;
      
  }

  delete(id) {
    return this.flightDetails.splice(this.flightDetails.indexOf(id),1);
  
  }

}

