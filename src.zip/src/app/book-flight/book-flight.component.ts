import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {

  errorMessage: String;
  successMessage: String;

  constructor(private fb: FormBuilder, private bookFlightService: BookFlightService) { }

  bookingForm = this.fb.group({
    passengerName: ['',Validators.required],
    noOfTickets: ['',[Validators.required,Validators.min(1)]],
    flightId: ['',[Validators.required,validateFlight]]
  })

  ngOnInit() {}



  book() {
    this.successMessage=null;
    this.errorMessage=null;
    console.log("hello");
    this.bookFlightService.getData(this.bookingForm.value).subscribe(
     (success)=>{
       console.log(success);
       this.successMessage=success.toString();
     },
     (error)=>{
      console.log(error);
      this.errorMessage=error.error.message;
     }
      );
    // Code the method here
  }
}

function validateFlight(c: FormControl) {
 /* 
    Code the validator here
    Use flightError as the property
*/
//console.log(c.value[3]);
// console.log(c.value[2].isUpperCase());
if(c.value.length===7 && c.value[3]==='-'){// && (c.value[0] && c.value[1] && c.value[0])){
  // console.log(c.value[3]);
  return null;
}else{
  return {flightError:true};
}

}


